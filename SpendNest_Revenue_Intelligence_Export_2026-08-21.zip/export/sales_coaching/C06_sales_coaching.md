# SpendNest Intelligence Output: C06
- **Source Type:** call
- **Source ID:** 12216d5c-e254-52c6-b344-47de4c6e1ae5
- **Applied Revision:** 1
- **Assigned Route:** sales_coaching

## Details
Refer to SpendNest dashboard and full conversation library for complete transcript analysis.
