# SpendNest Intelligence Output: C01
- **Source Type:** call
- **Source ID:** 2ec4404c-beee-5377-a63c-aab701da08ed
- **Applied Revision:** 1
- **Assigned Route:** sales_coaching

## Details
Refer to SpendNest dashboard and full conversation library for complete transcript analysis.
