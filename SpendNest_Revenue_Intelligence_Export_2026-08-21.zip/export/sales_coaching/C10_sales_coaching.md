# SpendNest Intelligence Output: C10
- **Source Type:** call
- **Source ID:** b747f592-810e-583c-9b81-8db5ab035806
- **Applied Revision:** 1
- **Assigned Route:** sales_coaching

## Details
Refer to SpendNest dashboard and full conversation library for complete transcript analysis.
