# SpendNest Intelligence Output: M10
- **Source Type:** meeting
- **Source ID:** 337f297d-9385-5b82-9e54-5019c1ed912c
- **Applied Revision:** 1
- **Assigned Route:** internal_vendor

## Details
Refer to SpendNest dashboard and full conversation library for complete transcript analysis.
