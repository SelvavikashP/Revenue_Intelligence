# SpendNest Intake Record: B20
- **Source Type:** call
- **Source ID:** 94b4f015-b243-5b89-b435-9957125ecdd4
- **Applied Revision:** 1
No usable transcript was supplied in this delivery.
