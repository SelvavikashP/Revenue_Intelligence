# SpendNest Intake Record: B10
- **Source Type:** call
- **Source ID:** 3ea930a1-0496-51e3-9dca-adc3be29331a
- **Applied Revision:** 1
No usable transcript was supplied in this delivery.
