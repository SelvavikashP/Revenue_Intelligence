# SpendNest Intake Record: B04
- **Source Type:** call
- **Source ID:** 530207ea-d67b-521a-8085-bdb9ae665417
- **Applied Revision:** 1
No usable transcript was supplied in this delivery.
