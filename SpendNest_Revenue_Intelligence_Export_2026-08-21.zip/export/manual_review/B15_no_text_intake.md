# SpendNest Intake Record: B15
- **Source Type:** call
- **Source ID:** 2ada5ab0-8a84-54b7-a071-cd5bd6ad5abd
- **Applied Revision:** 1
No usable transcript was supplied in this delivery.
