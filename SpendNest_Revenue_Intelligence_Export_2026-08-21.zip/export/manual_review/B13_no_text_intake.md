# SpendNest Intake Record: B13
- **Source Type:** call
- **Source ID:** 6521ed7d-53fc-5b3b-be77-7d4610c90ed7
- **Applied Revision:** 1
No usable transcript was supplied in this delivery.
