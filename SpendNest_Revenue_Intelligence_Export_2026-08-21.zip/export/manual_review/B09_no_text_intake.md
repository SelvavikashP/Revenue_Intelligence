# SpendNest Intake Record: B09
- **Source Type:** call
- **Source ID:** 747390bc-f359-5609-bf79-0a44ef8919bd
- **Applied Revision:** 1
No usable transcript was supplied in this delivery.
