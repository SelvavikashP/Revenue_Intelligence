# SpendNest Intake Record: M13
- **Source Type:** meeting
- **Source ID:** 794a9d1c-889d-5957-873f-8a1271b03455
- **Applied Revision:** 1
No usable transcript was supplied in this delivery.
