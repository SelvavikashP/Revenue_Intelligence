# SpendNest Intake Record: M12
- **Source Type:** meeting
- **Source ID:** c759b921-e9d3-540c-a06b-474c5710342d
- **Applied Revision:** 1
No usable transcript was supplied in this delivery.
