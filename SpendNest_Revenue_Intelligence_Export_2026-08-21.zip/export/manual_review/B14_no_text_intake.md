# SpendNest Intake Record: B14
- **Source Type:** call
- **Source ID:** 81da63f4-eac6-5efd-95e1-69ad6e6def25
- **Applied Revision:** 1
No usable transcript was supplied in this delivery.
