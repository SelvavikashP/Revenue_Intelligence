# SpendNest Intake Record: B02
- **Source Type:** call
- **Source ID:** 5747e4cd-e24f-5bed-bf74-9e3f326b2d77
- **Applied Revision:** 1
No usable transcript was supplied in this delivery.
