# SpendNest Intake Record: B07
- **Source Type:** call
- **Source ID:** f9be8537-1ad9-58fc-be24-78f73d09db9c
- **Applied Revision:** 1
No usable transcript was supplied in this delivery.
