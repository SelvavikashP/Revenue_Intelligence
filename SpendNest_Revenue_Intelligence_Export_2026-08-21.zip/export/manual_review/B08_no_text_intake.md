# SpendNest Intake Record: B08
- **Source Type:** call
- **Source ID:** 77350513-913c-5fed-b4e6-71009de9df03
- **Applied Revision:** 1
No usable transcript was supplied in this delivery.
