# SpendNest Intake Record: B11
- **Source Type:** call
- **Source ID:** bfefcb48-1a98-5610-a0ee-0f03434188a9
- **Applied Revision:** 1
No usable transcript was supplied in this delivery.
