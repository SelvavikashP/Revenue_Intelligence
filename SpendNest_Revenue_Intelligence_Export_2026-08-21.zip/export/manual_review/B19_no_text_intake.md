# SpendNest Intake Record: B19
- **Source Type:** call
- **Source ID:** 6ee11c0e-c74a-5805-b552-657443378b72
- **Applied Revision:** 1
No usable transcript was supplied in this delivery.
