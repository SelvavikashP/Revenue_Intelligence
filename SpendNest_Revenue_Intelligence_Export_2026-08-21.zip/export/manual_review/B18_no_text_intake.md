# SpendNest Intake Record: B18
- **Source Type:** call
- **Source ID:** 26c3ccc3-63a6-55f6-a5a3-e279b36b7e88
- **Applied Revision:** 1
No usable transcript was supplied in this delivery.
