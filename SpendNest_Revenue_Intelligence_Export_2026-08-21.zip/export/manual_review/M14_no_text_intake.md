# SpendNest Intake Record: M14
- **Source Type:** meeting
- **Source ID:** 93f4867d-65cd-5236-bc55-7bd57df8ac24
- **Applied Revision:** 1
No usable transcript was supplied in this delivery.
