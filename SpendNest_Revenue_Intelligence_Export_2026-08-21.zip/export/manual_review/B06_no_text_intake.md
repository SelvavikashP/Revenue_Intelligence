# SpendNest Intake Record: B06
- **Source Type:** call
- **Source ID:** 53f61c95-27b9-50c2-8755-08f957594950
- **Applied Revision:** 1
No usable transcript was supplied in this delivery.
