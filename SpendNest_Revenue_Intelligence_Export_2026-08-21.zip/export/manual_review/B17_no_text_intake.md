# SpendNest Intake Record: B17
- **Source Type:** call
- **Source ID:** 1645d595-1896-5201-9395-cb8a9f1c5f3a
- **Applied Revision:** 1
No usable transcript was supplied in this delivery.
