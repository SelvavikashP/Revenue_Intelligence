# SpendNest Intake Record: M11
- **Source Type:** meeting
- **Source ID:** fc651475-187c-5882-a644-b501408e8647
- **Applied Revision:** 1
No usable transcript was supplied in this delivery.
