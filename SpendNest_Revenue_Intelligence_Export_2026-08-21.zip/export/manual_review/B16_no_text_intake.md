# SpendNest Intake Record: B16
- **Source Type:** call
- **Source ID:** 1f5181ed-4175-5d73-a16b-01d404b1820d
- **Applied Revision:** 1
No usable transcript was supplied in this delivery.
