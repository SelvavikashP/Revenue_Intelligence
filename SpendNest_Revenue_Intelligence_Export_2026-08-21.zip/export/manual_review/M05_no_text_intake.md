# SpendNest Intake Record: M05
- **Source Type:** meeting
- **Source ID:** e0ecb112-ed94-5e8e-ae71-19def5536337
- **Applied Revision:** 1
No usable transcript was supplied in this delivery.
