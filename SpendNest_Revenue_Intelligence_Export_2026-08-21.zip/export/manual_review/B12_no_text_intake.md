# SpendNest Intake Record: B12
- **Source Type:** call
- **Source ID:** 9a64eb58-d462-5a6e-aa9e-c0f88852ebe0
- **Applied Revision:** 1
No usable transcript was supplied in this delivery.
