# SpendNest Intake Record: M08
- **Source Type:** meeting
- **Source ID:** 883182d8-eb86-56f9-a928-152365998d15
- **Applied Revision:** 1
No usable transcript was supplied in this delivery.
